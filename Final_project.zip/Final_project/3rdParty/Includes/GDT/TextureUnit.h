#pragma once

enum TextureUnit
{
    TEXTURE0 = 0,
    TEXTURE1 = 1,
    TEXTURE2 = 2,
    TEXTURE3 = 3,
    TEXTURE4 = 4,
    TEXTURE5 = 5,
    TEXTURE6 = 6,
    TEXTURE7 = 7,
    TEXTURE8 = 8
};
