﻿#include "Model.h"
#include "Image.h"

#include <GDT/Window.h>
#include <GDT/Input.h>
#include <GDT/Shader.h>
#include <GDT/Matrix4f.h>
#include <GDT/Vector3f.h>
#include <GDT/Math.h>
#include <GDT/OpenGL.h>

#include <vector>
#include <iostream>
#include <glm/trigonometric.hpp>

//#include <glad/glad.h>
#include <GLFW\glfw3.h>
#include<map>



Matrix4f lookAtMatrix(Vector3f camera, Vector3f target, Vector3f up)
{
	Vector3f forward = normalize(target - camera);
	Vector3f right = normalize(cross(forward, up));
	up = cross(right, forward);

	Matrix4f lookAtMatrix;
	lookAtMatrix[0] = right.x; lookAtMatrix[4] = right.y; lookAtMatrix[8] = right.z;
	lookAtMatrix[1] = up.x; lookAtMatrix[5] = up.y; lookAtMatrix[9] = up.z;
	lookAtMatrix[2] = -forward.x; lookAtMatrix[6] = -forward.y; lookAtMatrix[10] = -forward.z;

	Matrix4f translateMatrix;
	translateMatrix[12] = -camera.x;
	translateMatrix[13] = -camera.y;
	translateMatrix[14] = -camera.z;

	return lookAtMatrix * translateMatrix;
}

Matrix4f projectionMOrth(float top, float bottom, float left, float right, float far1, float near1)
{   // orthogonal
	Matrix4f pm;
	pm[0] = 2 / (right - left);
	pm[12] = -1 * (right + left) / (right - left);
	pm[5] = 2 / (top - bottom);
	pm[13] = -1 * (top + bottom) / (top - bottom);
	pm[10] = -2 / (far1 - near1);
	pm[14] = -1 * (far1 + near1) / (far1 - near1);
	pm[15] = 1;
	return pm;
}
Matrix4f projectionMPersp(float alpha, float ar, float nearz, float farz)
{
	Matrix4f pm;
	pm[0] = 1 / (ar* tan(alpha / 2));
	pm[5] = 1 / tan(alpha / 2);
	pm[10] = (nearz + farz) / (farz - nearz);
	pm[11] = 2 * (farz * nearz) / (nearz - farz);
	pm[14] = -1;
	pm[15] = 0;
	return pm;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Rudimentary function for drawing models, feel free to replace or change it with your own logic
// Just make sure you let the shader know whether the model has texture coordinates
void drawModel(ShaderProgram& shader, const Model& model, Vector3f position, float angle, float scale)
{
	shader.bind();
	Matrix4f modelMatrix;
	modelMatrix.translate(position);
	modelMatrix.rotate(angle,0,1,0); //Chen: I changed here, used to be: modelMatrix.rotate(rotation);  vector3f rotation 
	modelMatrix.scale(scale); 
		
	shader.uniformMatrix4f("modelMatrix", modelMatrix);
	shader.uniform1i("hasTexCoords", model.texCoords.size() > 0);
	//std::cout << model.texCoords.size() << std::endl;
	glBindVertexArray(model.vao);
	glDrawArrays(GL_TRIANGLES, 0, model.vertices.size());
}

class Application : KeyListener, MouseMoveListener, MouseClickListener
{
public:
	void init()
	{
		window.setGlVersion(3, 3, true);
		window.create("Final Project", 1024, 1024);
		
		window.addKeyListener(this);
		window.addMouseMoveListener(this);
		window.addMouseClickListener(this);

		try {
			defaultShader.create();
			defaultShader.addShader(VERTEX, "Resources/shader.vert");    /////////////////////////////////////////////////////
			defaultShader.addShader(FRAGMENT, "Resources/shader.frag");
			defaultShader.build();
			
			shadowShader.create();
			shadowShader.addShader(VERTEX, "Resources/shadow.vert");
			shadowShader.build();
			
			toonShader.create();
			toonShader.addShader(VERTEX, "Resources/toon.vert");
			toonShader.addShader(FRAGMENT, "Resources/toon.frag");
			toonShader.build();

			sceneShader.create();
			sceneShader.addShader(VERTEX, "Resources/sceneshader.vert");
			sceneShader.addShader(FRAGMENT, "Resources/sceneshader.frag");
			sceneShader.build();
		}
		
		catch (ShaderLoadingException e)
		{
			std::cerr << e.what() << std::endl;
		}

		// Upload the projection matrix once, if it doesn't change
		// during the game we don't need to reupload it
		//mag = 10.0f;
		projMatrix = projectionMOrth(10, -mag, -mag, mag, mag, -mag);//t,d,l,r,f,n
		//projMatrix = projectionM(PI / 3, 1, 1.5, -0.5);
		viewMatrix = lookAtMatrix(Vector3f(0, 5, 0), Vector3f(0, 1, 0), Vector3f(0, 1, 0));
		lightMatrix = lookAtMatrix(Vector3f(lightxpos, 3.0f, lightypos), Vector3f(0, 0, 0), Vector3f(0, 1, 0)); 

//////////////////////////////////////////////////////////// default shader ////////////////////////////////////////////////
		// Correspond the OpenGL texture units 0 and 1 with the
		// colorMap and shadowMap uniforms in the shader
		defaultShader.bind();
		defaultShader.uniform1i("colorMap", 0);
		defaultShader.uniform1i("shadowMap", 1);

		defaultShader.uniformMatrix4f("projMatrix", projMatrix);
		defaultShader.uniformMatrix4f("viewMatrix", viewMatrix);
		defaultShader.uniformMatrix4f("lightView", lightMatrix);     // for shadow 6.7
		defaultShader.uniform3f("viewPos", camPos);
		defaultShader.uniform3f("lightPos", Vector3f(lightxpos, 3.0f, lightypos));     // for shadow 6.7
/////////////////////////////////////////////////////////////// shadow shader ////////////////////////////////////////////////	
		shadowShader.bind();
		shadowShader.uniformMatrix4f("projMatrix", projMatrix); // Might need to be dedicated light projection matrix
		shadowShader.uniformMatrix4f("viewMatrix", lightMatrix); 
		
		glEnable(GL_DEPTH_TEST);
		glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
		
/////////////////////////////////////////////////////////////// scene shader ////////////////////////////////////////////////
		sceneShader.bind();
		sceneShader.uniform1i("colorMap", 0);
		sceneShader.uniform1i("shadowMap", 1);

		sceneShader.uniformMatrix4f("projMatrix", projMatrix);
		sceneShader.uniformMatrix4f("viewMatrix", viewMatrix);
		sceneShader.uniform3f("viewPos", camPos);
		sceneShader.uniformMatrix4f("lightView", lightMatrix);     // for shadow 6.7
		sceneShader.uniform3f("lightPos", Vector3f(lightxpos, 3.0f, lightypos));
		glEnable(GL_DEPTH_TEST);
		glClearColor(0.2f, 0.2f, 0.2f, 1.0f);

/////////////////////////////////////////////////////////////// toon shader ////////////////////////////////////////////////
		toonShader.bind();
		toonShader.uniform1i("colorMap", 0);
		toonShader.uniform1i("shadowMap", 1);

		toonShader.uniformMatrix4f("projMatrix", projMatrix);
		toonShader.uniformMatrix4f("viewMatrix", viewMatrix);
		toonShader.uniform3f("viewPos", camPos);
		toonShader.uniformMatrix4f("lightView", lightMatrix);    
		toonShader.uniform3f("lightPos", Vector3f(lightxpos, 3.0f, lightypos));
		glEnable(GL_DEPTH_TEST);
		glClearColor(0.2f, 0.2f, 0.2f, 1.0f);

/////////////////////////////////////////////////////////////// load model & tex ////////////////////////////////////////////////
		model_1 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/mylego.obj");
		model_2 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/land2.obj");
		model_3 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/maison.obj");
		model_4 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/tree.obj");
		model_6 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/friend1.obj");
		model_7 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/skybox60777.obj");
		model_8 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/win.obj");
		model_9 = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/no.obj");
		modelS = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/models.obj");

		for (int i = 1; i < 10; i++) {
			std::string varname = "model_" + std::to_string(i);
			model_set[varname] = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/Lego/lego_00000" + std::to_string(i) + ".obj");
		}
		for (int i = 10; i < 20; i++) {
			std::string varname = "model_" + std::to_string(i);
			model_set[varname] = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/Lego/lego_0000" + std::to_string(i) + ".obj");
		}
		model_index = 1;

		for (int i = 1; i < 8; i++) {
			std::string varnameB = "modelB_" + std::to_string(i);
			model_setB[varnameB] = loadModel("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/BB8/BB8_00000" + std::to_string(i) + ".obj");
		}
		model_indexB = 1;



		Tex1 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/skin.png");
		Tex2 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/land2.png");
		Tex3 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/maison.png");
		Tex4 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/tree.png");
		Tex5 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/skybox_texture.jpg");
		Tex6 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/friend1.png");
		Tex7 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/friend2.png");
		Tex8 = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/win.jpg");
		TexB = loadImage("C:/Users/YI/Desktop/TUD/3D_computer_graphics/Final_project/Source/models/Slide1.jpeg");
		//////////////////////////////////////////////////  shadow 6.7 /////////////////////////////////////////////////////
		glGenTextures(1, &shadowMap);
		glBindTexture(GL_TEXTURE_2D, shadowMap);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32F, SHADOWTEX_WIDTH, SHADOWTEX_HEIGHT, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
		glCullFace(GL_FRONT);
		// Set behaviour for when texture coordinates are outside the [0, 1] range
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);  // for avoiding black boundary due to the projection
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		float borderColor[] = { 1.0, 1.0, 1.0, 1.0 };
		glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);

        ///////////////////////////////// Set shadow texure as depth buffer for this framebuffer
		glGenFramebuffers(1, &framebuffer);
		glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
		glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, shadowMap, 0);
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
		glCullFace(GL_FRONT);
		//////////////////////////////////////////////////////////////////////////////
	}

	float lightxpos = 1.0f;
	float lightypos = 1.0f;
	float draw_x = 1.0f;
	float xPos = 25.0f;
	float zPos = -1.5f;
	float mag = 40.0f;
	float temp_mag = 30.0f;
	int anim_num = 0;

	////lookatmatrix////
	float camRotation = 1;
	float radius = 1.0f;
	float camX = 0;
	float camZ = 1;

	Vector3f camPos = Vector3f(0, 3.0, 0);
	Vector3f camFront = Vector3f(0, -0.5, -1);
	Vector3f camUp = Vector3f(0, 1, 0);
	Vector3f camTarg = Vector3f(0, 2.5, 0);


	///deltatime///
	float deltatime = 1.0f;
	float lastframe = 0.0f;
	float camSpeed = 10.0f * deltatime;
	int timestep = 1;
	int timestep1 = 1;
	int timestep2 = 1; 

	///mouse///
	bool firstMouse = true;
	float yaw = -90.0f;
	float pitch = 0.0f;
	float lastX = 512, lastY = 512;
	int button = -1;
	float PI = 3.141592;
	float horizontalAngle = 0.0f;
	float rotationAngle = 0.0f;
	float bodyRotationAngle = 0.0f;	
	float rotationAngle2 = 0.0f;

	/////MOVING//////
	float click_xPos = 0;
	float click_yPos = 0;
	int Mod = 1;
	int Viewmod = 1;
	Matrix4f projectionM;
	float moveAngle = 0;
	float scalen = 1;



	void update()
	{
		// This is your game loop
		// Put your real-time logic and rendering in here
		while (!window.shouldClose())
		{
			// Clear the screen
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

			float currentframe = glfwGetTime();
			deltatime = currentframe - lastframe;
			lastframe = currentframe;
			animate();

			if (Viewmod == 1)
			{	
				mag = 40;
				projMatrix = projectionMOrth(mag, -mag, -mag, mag, mag, -mag);
				lightproj = projectionMOrth(mag, -mag, -mag, mag, mag, -mag); 
				camPos = Vector3f(xPos - 8, 20.0f, zPos);
				camTarg = Vector3f(xPos + 2, 12.0, zPos + 2);
				viewMatrix = lookAtMatrix(camPos, camTarg, camUp);

				if (Mod == 2)  // right click mouse
				{
					mag = 30;
					camPos = Vector3f(xPos, 15.5f, zPos + 2.0f);
					camTarg = camPos + camFront - Vector3f(0, 0, 1);
					viewMatrix = lookAtMatrix(camPos, camTarg, camUp);

					projMatrix = projectionMOrth(mag, -mag, -mag, mag, mag, -mag);//t,d,l,r,f,n
					lightproj = projectionMOrth(mag, -mag, -mag, mag, mag, -mag);
					//std::cout <<" camPos: " << camPos.x<<" "<< camPos.y<<" "<< camPos.z<< std::endl;
				}
				else  // normally move mouse
				{

					if (Mod == 3)
					{
						moveAngle = bodyRotationAngle * PI / 180.0f;
						xPos -= 0.1*sin(moveAngle);
						zPos -= 0.1*cos(moveAngle);
					}
					if (Mod == 4)
					{
						moveAngle = bodyRotationAngle * PI / 180.0f;
						xPos += 0.1 * sin(moveAngle);
						zPos += 0.1 * cos(moveAngle);
					}

					//camPos = Vector3f(xPos, 15.5f, zPos + 2.0f);
					//camTarg = camPos + camFront - Vector3f(0, 0, 1);
					//camPos = Vector3f( - 8, 6.0f, 0);
					//camTarg = Vector3f(1, 0.0, 1);
					//std::cout <<" camPos: " << xPos<<" "<< zPos<< std::endl;
					//viewMatrix = lookAtMatrix(camPos, camTarg, camUp);
					//t,d,l,r,f,n
				}
			}
			if (Viewmod == 2)
			{
				mag = 40;
				lightproj = projectionMOrth(mag, -mag, -mag, mag, mag, -mag);
				projMatrix = projectionMPersp(PI / 3, 1, 1, -2);
				camPos = Vector3f(xPos, 5.2f, zPos + 8.0f);
				camTarg = Vector3f(xPos, 5.0f, zPos);
				viewMatrix = lookAtMatrix(camPos, camTarg, camUp);


				if (Mod == 2)  // right click mouse
				{
					mag = 30;
					camPos = Vector3f(xPos, 2.0f, zPos + 1.0f);
					camTarg = camPos + camFront - Vector3f(0, -0.5, 2.0f);
					viewMatrix = lookAtMatrix(camPos, camTarg, camUp);

					projMatrix = projectionMOrth(mag, -mag, -mag, mag, mag, -mag);//t,d,l,r,f,n
					lightproj = projectionMOrth(mag, -mag, -mag, mag, mag, -mag);
					//std::cout <<" camPos: " << camPos.x<<" "<< camPos.y<<" "<< camPos.z<< std::endl;
				}
				else  // normally move mouse
				{

					if (Mod == 3)
					{
						moveAngle = bodyRotationAngle * PI / 180.0f;
						xPos -= 0.1*sin(moveAngle);
						zPos -= 0.1*cos(moveAngle);
					}
					if (Mod == 4)
					{
						moveAngle = bodyRotationAngle * PI / 180.0f;
						xPos += 0.1 * sin(moveAngle);
						zPos += 0.1 * cos(moveAngle);
					}

					//camPos = Vector3f(xPos, 15.5f, zPos + 2.0f);
					//camTarg = camPos + camFront - Vector3f(0, 0, 1);
					//camPos = Vector3f( - 8, 6.0f, 0);
					//camTarg = Vector3f(1, 0.0, 1);
					//std::cout <<" camPos: " << xPos<<" "<< zPos<< std::endl;
					//viewMatrix = lookAtMatrix(camPos, camTarg, camUp);
					//t,d,l,r,f,n
				}
			}
			
			lightMatrix = lookAtMatrix(Vector3f(lightxpos, 3.0f, lightypos), Vector3f(0, 0, 0), camUp);  // use as view matrix for shadow shader
			/////////////////////////////////////////////////////////////////////////////////////////////////
			{	
				glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);	// Bind the off-screen framebuffer
				glClearDepth(1.0f);								// Clear the shadow map and set needed options
				glClear(GL_DEPTH_BUFFER_BIT);
				glEnable(GL_DEPTH_TEST);

				shadowShader.bind();							// Bind the shader
				shadowShader.uniformMatrix4f("projMatrix", lightproj); // Might need to have its own proj matrix
				shadowShader.uniformMatrix4f("viewMatrix", lightMatrix);
				glViewport(0, 0, SHADOWTEX_WIDTH, SHADOWTEX_HEIGHT);		 // Set viewport size
				glCullFace(GL_FRONT);										 // Execute draw command
																	   		
				drawModel(shadowShader, model, Vector3f(xPos, 0.0, zPos), bodyRotationAngle, 4.0f);
				drawModel(shadowShader, model_2, Vector3f(0.0f, 0.0f, 0.0f), 0.0f, 1.0f);
				drawModel(shadowShader, model_3, Vector3f(0.0f, -0.2f, -5.0f), 0.0f, 1.0f); //maison
				drawModel(shadowShader, model_4, Vector3f(0.0f, 0.0f, -20.0f), 0.0f, 1.2f); //tree
				drawModel(shadowShader, modelB, Vector3f(-11.5, -0.7, -24), -1.2, 0.25f);    //BB8
				drawModel(shadowShader, model_6, Vector3f(-5.0f, 0.0f, -36.0f), 60.0f, 4.0f); //friends
				drawModel(shadowShader, model_1, Vector3f(5.0f, 0.0f, -14.0f), 90.0f, 4.0f);
				
				glBindFramebuffer(GL_FRAMEBUFFER, 0);				// Unbind the off-screen framebuffer
				glCullFace(GL_BACK);
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////
			// update parameters
			defaultShader.bind();			// bind uniform each before shader
			defaultShader.uniformMatrix4f("projMatrix", projMatrix);     //////// default shader
			defaultShader.uniformMatrix4f("viewMatrix", viewMatrix);
			defaultShader.uniform3f("viewPos", camPos); 
			defaultShader.uniform3f("lightPos", Vector3f(lightxpos, 8.0f, lightypos));
			defaultShader.uniformMatrix4f("lightView", lightMatrix);     //////// for shadow 6.7
			
			sceneShader.bind();
			sceneShader.uniformMatrix4f("projMatrix", projMatrix);		 //////// scene shader
			sceneShader.uniformMatrix4f("viewMatrix", viewMatrix);   
			sceneShader.uniform3f("viewPos", camPos);				  
			sceneShader.uniform3f("lightPos", Vector3f(lightxpos, 8.0f, lightypos)); 
			sceneShader.uniformMatrix4f("lightView", lightMatrix);     //////// for shadow 6.7

			toonShader.bind();
			toonShader.uniformMatrix4f("projMatrix", projMatrix);		 //////// scene shader
			toonShader.uniformMatrix4f("viewMatrix", viewMatrix);
			toonShader.uniform3f("viewPos", camPos);
			toonShader.uniform3f("lightPos", Vector3f(lightxpos, 8.0f, lightypos));
			toonShader.uniformMatrix4f("lightView", lightMatrix);     //////// for shadow 6.7
			///////////////////////////////////////////////////////////////////////////
			GLint texture_unit = 1;
			glActiveTexture(GL_TEXTURE0 + texture_unit);
			glBindTexture(GL_TEXTURE_2D, shadowMap);
			defaultShader.uniform1i("shadowMap", texture_unit);
			// Set viewport size
			glViewport(0, 0, WIDTH, HEIGHT);
			// Clear the framebuffer to black and depth to maximum value
			glClearDepth(1.0f);
			glClearColor(0.1f, 0.2f, 0.3f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glEnable(GL_DEPTH_TEST);

			/////////////////////////////// Draw models ////////////////////////////////////
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Tex1.handle);
			drawModel(defaultShader, model, Vector3f(xPos, 0.0, zPos), bodyRotationAngle, 4.0f);

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, TexB.handle);
			drawModel(defaultShader, modelB, Vector3f(-11.5, -0.7, -24), -1.0, 0.25f);

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Tex2.handle);
			drawModel(sceneShader, model_2, Vector3f(0.0f, 0.0f, 0.0f), 0.0f, 1.0f);

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Tex3.handle);		   // maison
			drawModel(sceneShader, model_3, Vector3f(0.0f, -0.2f, -5.0f), 0.0f, 1.0f);

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Tex4.handle);		   // tree
			drawModel(toonShader, model_4, Vector3f(0.0f, 0.0f, -20.0f), 0.0f, 1.2f);

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Tex6.handle);		  // friend
			drawModel(defaultShader, model_6, Vector3f(-5.0f, 0.0f, -36.0f), 60.0f, 4.0f);

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Tex7.handle);
			drawModel(toonShader, model_1, Vector3f(5.0f, 0.0f, -14.0f), 90.0f, 4.0f);

			if (-7.0f< xPos &&  xPos<-3.0f  && -34.0f>zPos && zPos> -38.0f)
			{
				glActiveTexture(GL_TEXTURE0);
				glBindTexture(GL_TEXTURE_2D, Tex8.handle);		// win!!!
				drawModel(toonShader, model_8, Vector3f(-5.0f, -1.0f, -40.0f), 240, 6.0f);
			}

			if (3.0f< xPos &&  xPos<7.0f  && -12.0f>zPos && zPos> -16.0f)
			{
				glActiveTexture(GL_TEXTURE0);
				glBindTexture(GL_TEXTURE_2D, Tex8.handle);		// No!!!
				drawModel(toonShader, model_9, Vector3f(5.0f, 0.0f, -14.0f), 240, 3.0f);
			}

			if (-13.0f< xPos &&  xPos<-10.0f  && -22.0f>zPos && zPos> -26.0f)
			{
				glActiveTexture(GL_TEXTURE0);
				glBindTexture(GL_TEXTURE_2D, Tex8.handle);		// No!!!
				drawModel(toonShader, model_9, Vector3f(-11.5f, 0.0f, -24.0f), 240, 3.0f);
			}




			window.update();
		}
		//glDeleteFramebuffers(1, &framebuffer);
	}

	
	void animate()
	{
		timestep ++;      // for light
		timestep1 ++;	  // for animated charactor
		timestep2++;
		lightypos = -1*sin(timestep * PI / 360) - 2;
		lightxpos = 1*sin(timestep * PI / 360)-2;
        
		if (zPos < -45.0f)
			zPos = -45.0f;
		if (zPos > 5.0f)
			zPos = 5.0f;
		if (xPos < -25.0f)
			xPos = -25.0f;
		if (xPos > 25.0f)
			xPos = 25.0f;



		model = model_set["model_" + std::to_string(model_index)]; 
		if (timestep1 == 2)
		{
			model_index++; 
			timestep1 = 0;
		}
		if (model_index==19)
		{
			model_index = 1;
		}

		if (timestep1 == 6)
		{
			model_indexB++;
			timestep1 = 0;
		}
		if (model_indexB == 5)
		{
			model_indexB = 1;
		}
		
		if (Mod == 3 || Mod == 4)
		{
			model = model;
		}
		else
		{
			model = model_set["model_" + std::to_string(5)];
		}


		modelB = model_setB["modelB_" + std::to_string(model_indexB)];
		if (timestep2 == 10)
		{
			model_indexB++;
			timestep2 = 0;
		}
		if (model_indexB == 7)
		{
			model_indexB = 1;
		}



	}


	// In here you can handle key releases
	// key - Integer that corresponds to numbers in https://www.glfw.org/docs/latest/group__keys.html
	// mods - Any modifier keys pressed, like shift or control
	

	// If one of the mouse buttons is pressed this function will be called
// button - Integer that corresponds to numbers in https://www.glfw.org/docs/latest/group__buttons.html
// mods - Any modifier buttons pressed
	void onMouseClicked(int button, int mods)
	{
		//std::cout << "Pressed button: " << button << std::endl;
		if (button == 0)
		{
			Mod = 1;
			//onMouseMove(lastX, lastY);

		}

		else if (button == 1)
		{
			Mod = 2;
		}


	}

	// If the mouse is moved this function will be called with the x, y screen-coordinates of the mouse
	void onMouseMove(float x, float y)
	{
		
		if (Mod == 2)
		{
			//std::cout << "Mouse at position: " << x << " " << y << std::endl;
			if (firstMouse)  // aoivd flash
			{
				lastX = x;
				lastY = y;
				firstMouse = false;

			}

			float xoffset = x - lastX;
			float yoffset = lastY - y;
			lastX = x;
			lastY = y;

			float sensitivity = 0.3f; //important coefficient
			xoffset *= sensitivity;
			yoffset *= sensitivity;

			yaw += xoffset;
			pitch += yoffset;

			if (pitch > 89.0f)
				pitch = 89.0f;
			if (pitch < -89.0f)
				pitch = -89.0f;

			Vector3f front;
			front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
			front.y = sin(glm::radians(pitch));
			front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
			camFront = normalize(front);
			//std::cout << "camFront: " << camFront.x<<" "<<camFront.z << std::endl;
			horizontalAngle = atan(camFront.x / camFront.z);
			//std::cout << "horizontal Angle: " << horizontalAngle << std::endl;
			rotationAngle = 180.0f * horizontalAngle / PI;
			//bodyRotationAngle = rotationAngle;
		}
		else
		{
			if (firstMouse)  // aoivd flash
			{
				lastX = x;
				lastY = y;
				firstMouse = false;
			}

			float xoffset = x - lastX;
			float yoffset = lastY - y;
			lastX = x;
			lastY = y;

			float sensitivity = 0.3f; //important coefficient
			xoffset *= sensitivity;
			yoffset *= sensitivity;

			yaw += xoffset;
			pitch += yoffset;

			if (pitch > 89.0f)
				pitch = 89.0f;
			if (pitch < -89.0f)
				pitch = -89.0f;

			Vector3f front;
			front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
			front.y = sin(glm::radians(pitch));
			front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
			Vector3f bodyFront = normalize(front);
			//std::cout << "camFront: " << camFront.x<<" "<<camFront.z << std::endl;
			horizontalAngle = atan(bodyFront.x / bodyFront.z);
			//std::cout << "horizontal Angle: " << horizontalAngle << std::endl;
			bodyRotationAngle = 360.0f * horizontalAngle / PI;

		}
	}

	// In here you can handle key presses
// key - Integer that corresponds to numbers in https://www.glfw.org/docs/latest/group__keys.html
// mods - Any modifier keys pressed, like shift or control
	void onKeyPressed(int key, int mods)
	{
		//std::cout << "Key pressed: " << key << std::endl;

		switch (key) {
		case 68://D
			//draw_x += 0.1f;
			bodyRotationAngle -= 30.0f;
			if (bodyRotationAngle < -90.0f)
			{
				bodyRotationAngle = -90.0f;
			}
			key = 0;
			break;
		case 65://A
			//draw_x -= 0.1f;
			bodyRotationAngle += 30.0f;
			if (bodyRotationAngle > 90.0f)
			{
				bodyRotationAngle = 90.0f;
			}

			key = 0;
			break;
		case 87://W

			Mod = 3;
			key = 0;
			break;
		case 83://S

			Mod = 4;
			key = 0;
			break;
		case 45:
			mag -= 1.0f;
			key = 0;
			break;
		case 61:
			mag += 1.0f;
			key = 0;
			break;
		case 265:
			camPos += camFront * camSpeed;
			key = 0;
			break;
		case 264:
			camPos -= camFront * camSpeed;
			key = 0;
			break;
		case 263:
			camPos -= normalize(cross(camFront, camUp))*camSpeed; //strafe: create a right vector by crossing
			key = 0;
			break;
		case 262:
			camPos += normalize(cross(camFront, camUp))*camSpeed;
			key = 0;
			break;
		case 49://1
			Viewmod = 1;
			key = 0;
			std::cout << "Viewmode:" << Viewmod << std::endl;
			break;

		case 50://2
			Viewmod = 2;
			key = 0;
			std::cout << "Viewmode:" << Viewmod << std::endl;
			break;

		default:
			break;

		}



	}



	void onKeyReleased(int key, int mods)
	{
		if (key == 68, 65, 87, 83)
			Mod = 1;
	}


	// If one of the mouse buttons is released this function will be called
	// button - Integer that corresponds to numbers in https://www.glfw.org/docs/latest/group__buttons.html
	// mods - Any modifier buttons pressed
	void onMouseReleased(int buttonR, int mods)
	{
	//	std::cout << "Released button: " << button << std::endl;
		if (buttonR == 1)
		{
			Mod = 1;
		}
	}

private:
	Window window;

	// Shader for default rendering and for depth rendering
	ShaderProgram defaultShader;
	ShaderProgram shadowShader;
	ShaderProgram sceneShader;         ////////////////////////////////new 6.5
	ShaderProgram toonShader;

	// Projection and view matrices for you to fill in and use
	Matrix4f projMatrix;
	Matrix4f shadowprojMatrix;
	Matrix4f viewMatrix;
	Matrix4f lightproj;
	Matrix4f lightMatrix;  // for shadow mapping  6.5

	Model model_1;
	Model model_2;
	Model model_3;
	Model model_4;
	Model model_5;
	Model model_6;
	Model model_7;
	Model model_8;
	Model model_9;
	Model modelS;
	
	int model_index;
	int model_indexB;
	Model model;
	Model modelB;
	std::map<std::string, Model> model_set;
	std::map<std::string, Model> model_setB;

	Image Tex1;
	Image Tex2;
	Image Tex3;
	Image Tex4;
	Image Tex5;
	Image Tex6;
	Image Tex7;
	Image Tex8;
	Image TexB;

	GLuint shadowMap;
	GLuint framebuffer;

	const int SHADOWTEX_WIDTH = 2000;
	const int SHADOWTEX_HEIGHT = 2000;
	const int WIDTH = 2024;
	const int HEIGHT = 2024;
};

///////////////////////////////////////////////////////////////////////////////////////////////////////
int main()
{
	
	Application app;
	app.init();
	app.update();
	
	return 0;
}
